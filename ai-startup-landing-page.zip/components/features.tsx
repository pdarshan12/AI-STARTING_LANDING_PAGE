"use client"

import { Zap, Cpu, Rocket, Lock, BarChart3, Code2 } from "lucide-react"

const features = [
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Deploy your AI models in seconds with our optimized infrastructure",
    color: "cyan",
  },
  {
    icon: Cpu,
    title: "Advanced AI Models",
    description: "Access state-of-the-art LLMs and custom models trained on your data",
    color: "purple",
  },
  {
    icon: Lock,
    title: "Enterprise Security",
    description: "Bank-level encryption and compliance with GDPR, SOC 2, and ISO standards",
    color: "magenta",
  },
  {
    icon: Rocket,
    title: "Scalable Infrastructure",
    description: "Auto-scaling from startup to enterprise with zero downtime",
    color: "cyan",
  },
  {
    icon: Code2,
    title: "Developer Friendly",
    description: "Comprehensive APIs, SDKs, and documentation for quick integration",
    color: "purple",
  },
  {
    icon: BarChart3,
    title: "Real-time Analytics",
    description: "Monitor performance, usage, and costs with detailed dashboards",
    color: "magenta",
  },
]

const colorClasses = {
  cyan: "text-cyan-400 neon-border-cyan",
  purple: "text-purple-400 neon-border-purple",
  magenta: "text-magenta-400 neon-border-magenta",
}

export default function Features() {
  return (
    <section id="features" className="relative py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-text-pretty">
            Powerful Features Built for{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 text-transparent bg-clip-text">Scale</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to build, train, and deploy AI applications at scale
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon
            const colorClass = colorClasses[feature.color as keyof typeof colorClasses]

            return (
              <div
                key={index}
                className={`p-6 rounded-xl border border-border/30 backdrop-blur-sm hover-glow transition-all duration-300 group cursor-pointer`}
              >
                <div
                  className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${colorClass} bg-opacity-10`}
                >
                  <Icon
                    size={24}
                    className={
                      feature.icon === Zap
                        ? "text-cyan-400"
                        : feature.icon === Lock
                          ? "text-magenta-400"
                          : feature.icon === BarChart3
                            ? "text-magenta-400"
                            : feature.icon === Rocket
                              ? "text-cyan-400"
                              : "text-purple-400"
                    }
                  />
                </div>
                <h3 className="text-lg font-semibold mb-2 text-foreground">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
