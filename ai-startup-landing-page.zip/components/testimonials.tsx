"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"

const testimonials = [
  {
    quote:
      "NeuroSync transformed our AI development workflow. We reduced deployment time by 80% and can now ship features at lightning speed.",
    author: "Sarah Chen",
    role: "CTO, TechVenture AI",
    avatar: "SC",
  },
  {
    quote:
      "The platform's scalability is unmatched. We went from zero to processing 1M requests per day without any infrastructure headaches.",
    author: "Marcus Rodriguez",
    role: "Founder, DataFlow Inc",
    avatar: "MR",
  },
  {
    quote:
      "Best decision we made for our AI infrastructure. The security features and compliance certifications give us peace of mind.",
    author: "Emma Nakamura",
    role: "VP Engineering, SecureAI",
    avatar: "EN",
  },
]

export default function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0)

  const next = () => {
    setActiveIndex((activeIndex + 1) % testimonials.length)
  }

  const prev = () => {
    setActiveIndex((activeIndex - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section id="testimonials" className="relative py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-text-pretty">
            Loved by{" "}
            <span className="bg-gradient-to-r from-purple-400 to-magenta-400 text-transparent bg-clip-text">
              Innovators
            </span>
          </h2>
        </div>

        {/* Testimonial Carousel */}
        <div className="relative">
          <div className="neon-border-purple p-8 sm:p-12 rounded-2xl backdrop-blur-sm">
            {/* Stars */}
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={20} className="fill-cyan-400 text-cyan-400" />
              ))}
            </div>

            {/* Quote */}
            <p className="text-lg sm:text-xl text-foreground mb-6 italic leading-relaxed">
              "{testimonials[activeIndex].quote}"
            </p>

            {/* Author */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 via-purple-500 to-magenta-500 flex items-center justify-center text-sm font-bold text-background">
                {testimonials[activeIndex].avatar}
              </div>
              <div>
                <div className="font-semibold text-foreground">{testimonials[activeIndex].author}</div>
                <div className="text-sm text-muted-foreground">{testimonials[activeIndex].role}</div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === activeIndex ? "bg-purple-500 w-8" : "bg-muted hover:bg-muted-foreground/50"
                  }`}
                />
              ))}
            </div>

            <div className="flex gap-2">
              <button
                onClick={prev}
                className="p-2 rounded-lg border border-border hover:neon-border-cyan transition-colors"
              >
                <ChevronLeft size={20} />
              </button>
              <button
                onClick={next}
                className="p-2 rounded-lg border border-border hover:neon-border-purple transition-colors"
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
