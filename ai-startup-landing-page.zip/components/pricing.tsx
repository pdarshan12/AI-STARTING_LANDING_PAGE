"use client"

import { Check } from "lucide-react"

const plans = [
  {
    name: "Starter",
    price: "29",
    description: "Perfect for individual developers",
    features: [
      "Up to 100k API calls/month",
      "1 deployment environment",
      "Community support",
      "Basic analytics",
      "Standard models access",
    ],
    highlighted: false,
    borderColor: "neon-border-cyan",
  },
  {
    name: "Professional",
    price: "99",
    description: "For growing teams and startups",
    features: [
      "Unlimited API calls",
      "5 deployment environments",
      "Priority support",
      "Advanced analytics",
      "Custom model training",
      "Team collaboration tools",
      "API versioning",
    ],
    highlighted: true,
    borderColor: "neon-border-magenta",
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For large-scale operations",
    features: [
      "Unlimited everything",
      "Unlimited environments",
      "24/7 dedicated support",
      "White-label solution",
      "Custom SLA",
      "On-premise deployment",
      "Advanced security options",
    ],
    highlighted: false,
    borderColor: "neon-border-purple",
  },
]

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-text-pretty">
            Simple, Transparent{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-magenta-400 text-transparent bg-clip-text">Pricing</span>
          </h2>
          <p className="text-lg text-muted-foreground">Start free, scale as you grow. No credit card required.</p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-2xl transition-all duration-300 hover-glow ${
                plan.highlighted ? "md:scale-105" : ""
              }`}
            >
              {/* Card Background */}
              <div className={`p-8 rounded-2xl border backdrop-blur-sm ${plan.borderColor}`}>
                {/* Badge for highlighted plan */}
                {plan.highlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <div className="px-4 py-1 rounded-full bg-gradient-to-r from-magenta-500 to-purple-500 text-background text-xs font-bold">
                      Most Popular
                    </div>
                  </div>
                )}

                {/* Plan Info */}
                <div className="mb-8">
                  <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-foreground">${plan.price}</span>
                    {plan.price !== "Custom" && <span className="text-muted-foreground">/month</span>}
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start gap-3">
                      <Check size={20} className="text-cyan-400 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <button
                  className={`w-full py-3 px-6 rounded-lg font-semibold transition-all ${
                    plan.highlighted
                      ? "bg-gradient-to-r from-magenta-500 via-purple-500 to-cyan-500 text-background hover-glow hover:scale-105"
                      : "border border-border hover:bg-muted text-foreground hover-glow"
                  }`}
                >
                  {plan.price === "Custom" ? "Contact Sales" : "Get Started"}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ-like note */}
        <div className="text-center mt-12">
          <p className="text-sm text-muted-foreground">
            All plans include a 14-day free trial. No credit card required.{" "}
            <a href="#" className="text-cyan-400 hover:text-cyan-300 transition-colors">
              View all pricing details →
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
