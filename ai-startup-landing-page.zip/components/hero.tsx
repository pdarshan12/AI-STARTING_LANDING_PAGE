"use client"

import { ArrowRight, Play, Sparkles } from "lucide-react"

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/20 rounded-full mix-blend-screen filter blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-20 right-10 w-72 h-72 bg-cyan-500/20 rounded-full mix-blend-screen filter blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 w-72 h-72 bg-magenta-500/20 rounded-full mix-blend-screen filter blur-3xl animate-pulse"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-block mb-6">
            <div className="px-4 py-2 rounded-full border neon-border-purple flex items-center gap-2 text-sm text-cyan-300">
              <Sparkles size={16} />
              The Future of AI Development
            </div>
          </div>

          {/* Main Headline */}
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6 leading-tight">
            <span className="block text-text-pretty">Transform Ideas Into</span>
            <span className="block bg-gradient-to-r from-cyan-400 via-purple-400 to-magenta-400 text-transparent bg-clip-text">
              Intelligent Applications
            </span>
          </h1>

          {/* Subheading */}
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
            Build powerful AI-driven products with our cutting-edge platform. From prototype to production, we've got
            you covered with enterprise-grade tools and infrastructure.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <button className="group relative px-8 py-4 bg-gradient-to-r from-cyan-500 via-purple-500 to-magenta-500 text-background font-semibold rounded-xl hover-glow hover:scale-105 transition-transform flex items-center gap-2">
              Start Building Now
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-8 py-4 border neon-border-cyan text-foreground font-semibold rounded-xl hover:bg-muted/50 transition-colors flex items-center gap-2">
              <Play size={20} />
              Watch Demo
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto">
            <div className="p-4 rounded-lg border border-border/30 hover-glow transition-all">
              <div className="text-2xl font-bold text-cyan-400">10k+</div>
              <div className="text-xs text-muted-foreground">Active Developers</div>
            </div>
            <div className="p-4 rounded-lg border border-border/30 hover-glow transition-all">
              <div className="text-2xl font-bold text-purple-400">98%</div>
              <div className="text-xs text-muted-foreground">Uptime SLA</div>
            </div>
            <div className="p-4 rounded-lg border border-border/30 hover-glow transition-all">
              <div className="text-2xl font-bold text-magenta-400">50ms</div>
              <div className="text-xs text-muted-foreground">Avg Response</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
