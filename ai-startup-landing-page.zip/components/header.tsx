"use client"

import { useState } from "react"
import { Menu, X, Sparkles } from "lucide-react"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 w-full z-50 border-b border-border/30 bg-background/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer hover-glow">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 via-purple-500 to-magenta-500 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-background" />
            </div>
            <span className="text-xl font-bold glow-magenta">NeuroSync</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#testimonials" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Testimonials
            </a>
            <a href="#pricing" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Docs
            </a>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-4">
            <button className="px-6 py-2 text-sm font-medium text-foreground hover:text-accent transition-colors">
              Sign In
            </button>
            <button className="px-6 py-2 text-sm font-medium bg-gradient-to-r from-cyan-500 via-purple-500 to-magenta-500 text-background rounded-lg hover-glow hover:scale-105 transition-transform">
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-3 border-t border-border/30 pt-4">
            <a href="#features" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a
              href="#testimonials"
              className="block text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Testimonials
            </a>
            <a href="#pricing" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </a>
            <a href="#" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
              Docs
            </a>
            <div className="flex gap-3 pt-3">
              <button className="flex-1 px-4 py-2 text-sm font-medium border border-border hover:border-primary transition-colors rounded-lg">
                Sign In
              </button>
              <button className="flex-1 px-4 py-2 text-sm font-medium bg-gradient-to-r from-cyan-500 via-purple-500 to-magenta-500 text-background rounded-lg hover-glow">
                Get Started
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
